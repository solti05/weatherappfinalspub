package com.example.weatherappfinals;

import java.util.List;

public class NewsResponse {
    public String status;
    public List<Article> news;
}
