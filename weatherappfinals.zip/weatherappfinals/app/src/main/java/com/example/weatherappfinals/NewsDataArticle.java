package com.example.weatherappfinals;

public class NewsDataArticle {
    public String title;
    public String link;
    public String description;
    public String content;
    public String pubDate;
    public String image_url;
    public String source_id;
}
