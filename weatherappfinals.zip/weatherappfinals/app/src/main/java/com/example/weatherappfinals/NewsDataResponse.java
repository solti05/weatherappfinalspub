package com.example.weatherappfinals;

import java.util.List;

public class NewsDataResponse {
    public String status;
    public int totalResults;
    public List<NewsDataArticle> results;
}
